package steps;

import Aggregator.UI.LoginTest;
import Aggregator.services.PlatformFee;
import Aggregator.utiles.DBUtils;
import Aggregator.utiles.ScenarioContext;
import com.fasterxml.jackson.databind.ObjectMapper;
import io.cucumber.datatable.DataTable;
import io.cucumber.java.en.And;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.restassured.response.Response;
import org.slf4j.LoggerFactory;
import java.util.Map;


public class MyStepdefs {
    private static final org.slf4j.Logger logger = LoggerFactory.getLogger(MyStepdefs.class);

    LoginTest loginTest = new LoginTest();
    DBUtils dbUtils = new DBUtils();
    PlatformFee platformFee = new PlatformFee();
    ObjectMapper objectMapper = new ObjectMapper();
    Response response;
    ScenarioContext context = new ScenarioContext();


    @Given("create data for EPOSPGDetailsList")
    public void createDataForEPOSPGDetailsList(DataTable table) {
        Map<String, String> map = table.asMap(String.class, String.class);
        Integer benEntityId = Integer.valueOf(map.get("benEntityId"));
        Integer hubPosId = Integer.valueOf(map.get("hubPosId"));
        response= platformFee.platform_fee_addEPOSPGDetailsList_test(benEntityId,hubPosId);
    }



    @Then("verify database {string} check processed with {int}")
    public void verifyDatabaseCheckProcess(String tableName,int processed) throws InterruptedException {
        if(processed==1){
            logger.info("Waiting for Job Running.....");
            System.out.println("Waiting for Job Running.....");
            Thread.sleep(20000);
            platformFee.isProcess(tableName,processed);
        }else{
            platformFee.isProcess(tableName,processed);
        }

    }

    @Then("Now run the Job from UI process the record")
    public void nowRunTheJobFromUIProcessTheRecord() {
        loginTest.testSuccessfulLogin();
    }


    @And("i should see the following in the resonsebody")
    public void iShouldSeeTheFollowingInTheResponseBody(DataTable table)  {
        Map<String, String> map = table.asMap(String.class, String.class);
        platformFee.responseValidation(map);
    }

    @Then("the status code should be {int}")
    public void theStatusCodeShouldBe(int arg0) {
        platformFee.verifyStatusCode(arg0);
    }

}
