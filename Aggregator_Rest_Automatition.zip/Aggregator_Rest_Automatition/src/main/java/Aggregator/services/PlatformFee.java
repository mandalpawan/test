package Aggregator.services;

import static Aggregator.pojo.addEPOSPGDetailsList.BaseClass.generateEpospgDetail;
import static Aggregator.utiles.Aggregator_Request.*;
import static org.testng.Assert.assertEquals;


import Aggregator.pojo.addEPOSPGDetailsList.BaseClass;

import Aggregator.pojo.transaction.KafkaMessage;
import Aggregator.utiles.ConfigLoader;
import Aggregator.utiles.DBUtils;
import Aggregator.utiles.ScenarioContext;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import io.cucumber.java.en.Then;
import io.restassured.response.Response;
import org.checkerframework.checker.units.qual.K;
import org.testng.annotations.Test;

import java.util.Random;
import java.util.*;

public class PlatformFee {
    ConfigLoader configLoader = new ConfigLoader();
    DBUtils dbUtils = new DBUtils();
    Response response;
    ScenarioContext context = new ScenarioContext();
    ObjectMapper objectMapper = new ObjectMapper();
    private static final Random RANDOM = new Random();
    long externalReferenceId;

    public Response platform_fee_addEPOSPGDetailsList_test(int benEntityId,int hubPosId){
        String baseURL = configLoader.getData("baseURL");
        String endpoint = configLoader.getData("endpoint");;
        externalReferenceId = 1000000000L + (long)(RANDOM.nextDouble() * 9000000000L);



        BaseClass mainClass = new BaseClass();
        mainClass.setExternalReferenceId(externalReferenceId);
        mainClass.setisEPOSRequest(false);
        mainClass.setEpospgDetails(Arrays.asList(generateEpospgDetail(benEntityId,hubPosId)));
        objectMapper = new ObjectMapper();
        try {
            String data = objectMapper.writeValueAsString(mainClass);
            response = postAPI(baseURL,endpoint,data);
            context.setPreviousResponse(response);
        } catch (JsonProcessingException e) {
            e.printStackTrace();
        }        BaseClass baseClass = new BaseClass();

        return response;
    }


    public void responseValidation(Map<String, String> map ){
        Map<String, Object> responseMap = null;
        try {
            responseMap = objectMapper.readValue(response.asString(), HashMap.class);
            for (Map.Entry<String, Object> entry : responseMap.entrySet()) {
//                Object actaual =  responseMap.get(entry.getKey());
//                String expected = (String) entry.getValue();
//                System.out.println(entry.getKey() + ":" + entry.getValue());
                assertEquals(responseMap.get(entry.getKey()), entry.getValue(), "Expected value"+entry.getValue() +"Actual Value"+responseMap.get(entry.getKey()));
            }
        } catch (JsonProcessingException e) {
            e.printStackTrace();
        }
    }

    public  void isProcess(String tableName,int processed){
        dbUtils.checkStatus(tableName,processed,externalReferenceId);
    }

    public void verifyStatusCode(int args){
        assertEquals(args, response.getStatusCode(), "Expected status code 200");
    }

    @Test
    public void test(){
        KafkaMessage kafkaMessage = new KafkaMessage();
        objectMapper = new ObjectMapper();
        kafkaMessage.generateSampleData();
        try {
            String data = objectMapper.writeValueAsString(kafkaMessage);
            System.out.println("------------------------------------------------");
            System.out.println(data);
        } catch (JsonProcessingException e) {
            e.printStackTrace();
        }
    }

}
