package Aggregator.UI;

import Aggregator.utiles.ConfigLoader;
import org.openqa.selenium.Alert;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

import java.time.Duration;

public class LoginTest {
    private WebDriver driver;
    private LoginPage loginPage;

    ConfigLoader configLoader = new ConfigLoader();
    private  String username;
    private  String password;

    public LoginTest(){
        driver = new ChromeDriver();
        loginPage = new LoginPage(driver);
        username = configLoader.getData("userName");
        password = configLoader.getData("password");
    }

    public void updateNextFireTime(){
        WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(10));
        Alert alert = wait.until(ExpectedConditions.alertIsPresent());
//        Alert alert = driver.switchTo().alert();
        alert.accept();
    }

    public void testSuccessfulLogin() {
        loginPage.enterUsername(username);
        loginPage.enterPassword(password);
        loginPage.clickLogin();
        loginPage.clickOnadministration();
        loginPage.clicOnqrtz_trigger();
        loginPage.selectJobRun();
        loginPage.clickupdateJob();
        this.updateNextFireTime();
        driver.quit();
    }

}
