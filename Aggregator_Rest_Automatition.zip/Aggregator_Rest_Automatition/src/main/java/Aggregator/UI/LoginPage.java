package Aggregator.UI;

import Aggregator.utiles.ConfigLoader;
import org.openqa.selenium.Alert;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.ui.Select;

public class LoginPage extends BasePage {
    private WebDriver driver;
    ConfigLoader configLoader = new ConfigLoader();
    private  String username;
    private  String password;

    public LoginPage(WebDriver driver) {
        super(driver);
    }

    @FindBy(id = "j_username")
    private WebElement usernameField;

    @FindBy(name = "j_password")
    private WebElement passwordField;

    @FindBy(className = "login_box_button")
    private WebElement loginButton;

    @FindBy(xpath = "//*[contains(text(),'Administration')]")
    private WebElement administration;

    @FindBy(xpath = "//*[contains(text(),'QRTZ Trigger')]")
    private WebElement qrtz_trigger;

    @FindBy(id = "triggers")
    private WebElement trigger;

    @FindBy(className = "sign_in_button")
    private WebElement updateJob;

    public void enterUsername(String username) {
        usernameField.sendKeys(username);
    }

    public void enterPassword(String password) {
        passwordField.sendKeys(password);
    }

    public void clickLogin() {
        loginButton.click();
    }

    public  void clickOnadministration(){
        administration.click();
    }

    public void clicOnqrtz_trigger(){
        qrtz_trigger.click();
    }

    public  void selectJobRun(){
        Select select = new Select(trigger);
        select.selectByValue("lmsStagingForPGAndEPOSSyncJob");
    }

    public void clickupdateJob(){
        updateJob.click();
    }

}

