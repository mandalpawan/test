package Aggregator.UI;

import Aggregator.utiles.ConfigLoader;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.support.PageFactory;

import java.util.concurrent.TimeUnit;

public class BasePage {
    protected WebDriver driver;
    private ConfigLoader configLoader = new ConfigLoader();
    final String url = configLoader.getData("baseURL") + configLoader.getData("uiendpoint");

    public BasePage(WebDriver driver) {
        this.driver = driver;
        PageFactory.initElements(driver, this);
        driver.get(url);
        driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);

    }
}
