
package Aggregator.pojo.addEPOSPGDetailsList;

import java.io.Serializable;
import java.util.List;


import com.fasterxml.jackson.annotation.JsonProperty;

public class AdditionalPrice implements Serializable
{

    @JsonProperty("templateType")
    private String templateType;
    @JsonProperty("slabs")
    private List<Object> slabs;
    @JsonProperty("rateType")
    private Integer rateType;
    @JsonProperty("rate")
    private Integer rate;
    @JsonProperty("instrumentType")
    private Integer instrumentType;
    @JsonProperty("feeType")
    private Integer feeType;
    private final static long serialVersionUID = -386156748731954613L;

    @JsonProperty("templateType")
    public String getTemplateType() {
        return templateType;
    }

    @JsonProperty("templateType")
    public void setTemplateType(String templateType) {
        this.templateType = templateType;
    }

    @JsonProperty("slabs")
    public List<Object> getSlabs() {
        return slabs;
    }

    @JsonProperty("slabs")
    public void setSlabs(List<Object> slabs) {
        this.slabs = slabs;
    }

    @JsonProperty("rateType")
    public Integer getRateType(int i) {
        return rateType;
    }

    @JsonProperty("rateType")
    public void setRateType(Integer rateType) {
        this.rateType = rateType;
    }

    @JsonProperty("rate")
    public Integer getRate() {
        return rate;
    }

    @JsonProperty("rate")
    public void setRate(Integer rate) {
        this.rate = rate;
    }

    @JsonProperty("instrumentType")
    public Integer getInstrumentType() {
        return instrumentType;
    }

    @JsonProperty("instrumentType")
    public void setInstrumentType(Integer instrumentType) {
        this.instrumentType = instrumentType;
    }

    @JsonProperty("feeType")
    public Integer getFeeType() {
        return feeType;
    }

    @JsonProperty("feeType")
    public void setFeeType(Integer feeType) {
        this.feeType = feeType;
    }



}
