
package Aggregator.pojo.addEPOSPGDetailsList;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.List;

public class BaseClass {
    private boolean isEPOSRequest;
    private long externalReferenceId;
    private List<EpospgDetail> epospgDetails;

    public BaseClass() {
        this.epospgDetails = new ArrayList<>();
    }



    public boolean isEPOSRequest() {
        return isEPOSRequest;
    }

    public void setisEPOSRequest(boolean isEPOSRequest) {
        this.isEPOSRequest = isEPOSRequest;
    }

    public long getExternalReferenceId() {
        return externalReferenceId;
    }

    public void setExternalReferenceId(long externalReferenceId) {
        this.externalReferenceId = externalReferenceId;
    }

    public List<EpospgDetail> getEpospgDetails() {
        return epospgDetails;
    }

    public void setEpospgDetails(List<EpospgDetail> epospgDetails) {
        this.epospgDetails = epospgDetails;
    }


    public static EpospgDetail generateEpospgDetail(int benEntityId,int hubPosId) {
        EpospgDetail detail = new EpospgDetail();
        detail.setStartEffectiveDate(null);
        detail.setSettlementMode(2);
        detail.setSdsInfo(Collections.emptyList());
        detail.setOperationType(1);
        detail.setModeOfPay("NEFT");
        detail.setMerchantCategoryCode("5697");
        detail.setLmsReferenceId(null); // Set to null
        detail.setEnableAnnualTurnover(true);
        detail.setEmail("pawan.mandal01@pinelabs.com");
        detail.setContactPerson("Pawan Mandal");
        detail.setContactNo("9643376314");
        detail.setCentralMerchantId(776480);
        detail.setBenName("new Merchant 2 Apr");
        detail.setBenIfsc("HDFC0007523");
        detail.setBenBankName("9");
        detail.setBenBankBranch("NA");
        detail.setBenAccNo("5600987589123");
        detail.setAnnualTurnover(15000000);
//        detail.setLmsReferenceId("null");
        BenConfiguration benConfig = new BenConfiguration();
        benConfig.setBenEntityLevel("POS");
        benConfig.setBenEntityId(benEntityId);
        detail.setBenConfiguration(Arrays.asList(benConfig));

        detail.setOtherMdrDetails(Arrays.asList(generateOtherMdrDetail(hubPosId)));

        return detail;
    }

    public static OtherMdrDetail generateOtherMdrDetail(int hubPosId) {
        OtherMdrDetail otherMdrDetail = new OtherMdrDetail();
        otherMdrDetail.setSource(2);
        otherMdrDetail.setMdrDetails(Arrays.asList(generateMdrDetail(hubPosId)));
        return otherMdrDetail;
    }

    public static MdrDetail generateMdrDetail(int hubPosId) {
        MdrDetail mdrDetail = new MdrDetail();
        mdrDetail.setProgram(6);
        mdrDetail.setNavCustId("CUST232264");
        mdrDetail.setHubPosId(hubPosId);
        mdrDetail.setAcquirer("ICICI UPI");

        mdrDetail.setMdr(Arrays.asList(generateMdr1(), generateMdr2()));
        return mdrDetail;
    }

    public static Mdr generateMdr1() {
        Mdr mdr = new Mdr();
        mdr.setType(2);
        mdr.setKey3("SAVINGS");
//        mdr.setKey2("null"); // Set to null

        TransactionType transactionType = new TransactionType();
        transactionType.setRateType(1);
        transactionType.setRate(13000);
//        transactionType.setNetworkName("null"); // Set to null
//        transactionType.setInstrumentType("null"); // Set to null
        transactionType.setFeeType(1);
        transactionType.setSlabs(Collections.emptyList()); // Empty array
        mdr.setTransactionType(Arrays.asList(transactionType));

        AdditionalPrice additionalPrice = new AdditionalPrice();
        additionalPrice.setTemplateType("PLATFORM_FEE");
        additionalPrice.setRateType(1);
        additionalPrice.setRate(15000);
        additionalPrice.setInstrumentType(7);
        additionalPrice.setFeeType(1);
        additionalPrice.setSlabs(Collections.emptyList()); // Empty array
        mdr.setAdditionalPrices(Arrays.asList(additionalPrice));

        return mdr;
    }

    public static Mdr generateMdr2() {
        Mdr mdr = new Mdr();
        mdr.setType(2);
//        mdr.setKey3("null"); // Set to null
//        mdr.setKey2("null"); // Set to null

        TransactionType transactionType = new TransactionType();
        Slab slab1 = new Slab();
        slab1.setUpperLimit(200000);
        slab1.setRateType(1);
        slab1.setRate(10000);
        slab1.setLowerLimit(0);

        Slab slab2 = new Slab();
        slab2.setUpperLimit(99999999);
        slab2.setRateType(1);
        slab2.setRate(20000);
        slab2.setLowerLimit(200001);

        transactionType.setSlabs(Arrays.asList(slab1, slab2));
//        transactionType.setRateType("null"); // Set to null
//        transactionType.setRate("null"); // Set to null
//        transactionType.setNetworkName("null"); // Set to null
//        transactionType.setInstrumentType("null"); // Set to null
        transactionType.setFeeType(2);
        mdr.setTransactionType(Arrays.asList(transactionType));
        mdr.setAdditionalPrices(Collections.emptyList()); // Empty array

        return mdr;
    }


}
