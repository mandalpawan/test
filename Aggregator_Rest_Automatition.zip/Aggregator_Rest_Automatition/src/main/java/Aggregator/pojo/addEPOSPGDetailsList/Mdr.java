
package Aggregator.pojo.addEPOSPGDetailsList;

import java.io.Serializable;
import java.util.List;

import com.fasterxml.jackson.annotation.JsonProperty;



public class Mdr implements Serializable
{

    @JsonProperty("type")
    private Integer type;
    @JsonProperty("transactionType")
    private List<TransactionType> transactionType;
    @JsonProperty("key3")
    private Object key3;
    @JsonProperty("key2")
    private Object key2=null;
    @JsonProperty("additionalPrices")
    private List<AdditionalPrice> additionalPrices;


    @JsonProperty("type")
    public Integer getType() {
        return type;
    }

    @JsonProperty("type")
    public void setType(Integer type) {
        this.type = type;
    }

    @JsonProperty("transactionType")
    public List<TransactionType> getTransactionType() {
        return transactionType;
    }

    @JsonProperty("transactionType")
    public void setTransactionType(List<TransactionType> transactionType) {
        this.transactionType = transactionType;
    }

    @JsonProperty("key3")
    public Object getKey3() {
        return key3;
    }

    @JsonProperty("key3")
    public void setKey3(Object key3) {
        this.key3 = key3;
    }

    @JsonProperty("key2")
    public Object getKey2() {
        return key2;
    }

    @JsonProperty("key2")
    public void setKey2(Object key2) {
        this.key2 = key2;
    }

    @JsonProperty("additionalPrices")
    public List<AdditionalPrice> getAdditionalPrices() {
        return additionalPrices;
    }

    @JsonProperty("additionalPrices")
    public void setAdditionalPrices(List<AdditionalPrice> additionalPrices) {
        this.additionalPrices = additionalPrices;
    }

}
