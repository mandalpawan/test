
package Aggregator.pojo.addEPOSPGDetailsList;

import java.io.Serializable;

import com.fasterxml.jackson.annotation.JsonProperty;



public class Slab implements Serializable
{
    @JsonProperty("upperLimit")
    private Integer upperLimit;
    @JsonProperty("rateType")
    private Integer rateType;
    @JsonProperty("rate")
    private Integer rate;
    @JsonProperty("lowerLimit")
    private Integer lowerLimit;
    private final static long serialVersionUID = 7507564991935652966L;

    @JsonProperty("upperLimit")
    public Integer getUpperLimit() {
        return upperLimit;
    }

    @JsonProperty("upperLimit")
    public void setUpperLimit(Integer upperLimit) {
        this.upperLimit = upperLimit;
    }

    @JsonProperty("rateType")
    public Integer getRateType() {
        return rateType;
    }

    @JsonProperty("rateType")
    public void setRateType(Integer rateType) {
        this.rateType = rateType;
    }

    @JsonProperty("rate")
    public Integer getRate() {
        return rate;
    }

    @JsonProperty("rate")
    public void setRate(Integer rate) {
        this.rate = rate;
    }

    @JsonProperty("lowerLimit")
    public Integer getLowerLimit() {
        return lowerLimit;
    }

    @JsonProperty("lowerLimit")
    public void setLowerLimit(Integer lowerLimit) {
        this.lowerLimit = lowerLimit;
    }

}
