package Aggregator.pojo.addEPOSPGDetailsList;

import java.io.Serializable;
import java.util.List;


public class TransactionType implements Serializable
{

    private List<Slab> slabs;

    private Object rateType;

    private Object rate;

    private Object networkName=null;

    private Object instrumentType=null;

    private Integer feeType;



    public List<Slab> getSlabs() {
        return slabs;
    }


    public void setSlabs(List<Slab> slabs) {
        this.slabs = slabs;
    }


    public Object getRateType() {
        return rateType;
    }


    public void setRateType(Object rateType) {
        this.rateType = rateType;
    }


    public Object getRate() {
        return rate;
    }


    public void setRate(Object rate) {
        this.rate = rate;
    }


    public Object getNetworkName() {
        return networkName;
    }


    public void setNetworkName(Object networkName) {
        this.networkName = networkName;
    }


    public Object getInstrumentType() {
        return instrumentType;
    }


    public void setInstrumentType(Object instrumentType) {
        this.instrumentType = instrumentType;
    }


    public Integer getFeeType() {
        return feeType;
    }


    public void setFeeType(Integer feeType) {
        this.feeType = feeType;
    }


}
