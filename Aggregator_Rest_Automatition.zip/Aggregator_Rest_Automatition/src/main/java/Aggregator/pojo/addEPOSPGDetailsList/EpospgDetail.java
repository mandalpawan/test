package Aggregator.pojo.addEPOSPGDetailsList;

import java.io.Serializable;
import java.util.List;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;


public class EpospgDetail implements Serializable
{

    private Object startEffectiveDate;
    @JsonProperty("settlementMode")
    private Integer settlementMode;
    @JsonProperty("sds_Info")
    private List<Object> sds_Info;
    @JsonProperty("otherMdrDetails")
    private List<OtherMdrDetail> otherMdrDetails;
    @JsonProperty("operationType")
    private Integer operationType;
    @JsonProperty("modeOfPay")
    private String modeOfPay;
    @JsonProperty("merchantCategoryCode")
    private String merchantCategoryCode;
    @JsonProperty("lmsReferenceId")
    private Object lmsReferenceId;
    @JsonProperty("enableAnnualTurnover")
    private Boolean enableAnnualTurnover;
    @JsonProperty("email")
    private String email;
    @JsonProperty("contactPerson")
    private String contactPerson;
    @JsonProperty("contactNo")
    private String contactNo;
    @JsonProperty("centralMerchantId")
    private Integer centralMerchantId;
    @JsonProperty("benName")
    private String benName;
    @JsonProperty("benIfsc")
    private String benIfsc;
    @JsonProperty("benConfiguration")
    private List<BenConfiguration> benConfiguration;
    @JsonProperty("benBankName")
    private String benBankName;
    @JsonProperty("benBankBranch")
    private String benBankBranch;
    @JsonProperty("benAccNo")
    private String benAccNo;
    @JsonProperty("annualTurnover")
    private Integer annualTurnover;




    public Object getStartEffectiveDate() {
        return startEffectiveDate;
    }


    public void setStartEffectiveDate(Object startEffectiveDate) {
        this.startEffectiveDate = startEffectiveDate;
    }

    @JsonProperty("settlementMode")
    public Integer getSettlementMode() {
        return settlementMode;
    }

    @JsonProperty("settlementMode")
    public void setSettlementMode(Integer settlementMode) {
        this.settlementMode = settlementMode;
    }

    @JsonProperty("sds_Info")
    public List<Object> getSdsInfo() {
        return sds_Info;
    }

    @JsonProperty("sds_Info")
    public void setSdsInfo(List<Object> sds_Info) {
        this.sds_Info = sds_Info;
    }

    @JsonProperty("otherMdrDetails")
    public List<OtherMdrDetail> getOtherMdrDetails() {
        return otherMdrDetails;
    }

    @JsonProperty("otherMdrDetails")
    public void setOtherMdrDetails(List<OtherMdrDetail> otherMdrDetails) {
        this.otherMdrDetails = otherMdrDetails;
    }

    @JsonProperty("operationType")
    public Integer getOperationType() {
        return operationType;
    }

    @JsonProperty("operationType")
    public void setOperationType(Integer operationType) {
        this.operationType = operationType;
    }

    @JsonProperty("modeOfPay")
    public String getModeOfPay() {
        return modeOfPay;
    }

    @JsonProperty("modeOfPay")
    public void setModeOfPay(String modeOfPay) {
        this.modeOfPay = modeOfPay;
    }

    @JsonProperty("merchantCategoryCode")
    public String getMerchantCategoryCode() {
        return merchantCategoryCode;
    }

    @JsonProperty("merchantCategoryCode")
    public void setMerchantCategoryCode(String merchantCategoryCode) {
        this.merchantCategoryCode = merchantCategoryCode;
    }

    @JsonProperty("lmsReferenceId")
    public Object getLmsReferenceId() {
        return lmsReferenceId;
    }

    @JsonProperty("lmsReferenceId")
    public void setLmsReferenceId(Object lmsReferenceId) {
        this.lmsReferenceId = lmsReferenceId;
    }

    @JsonProperty("enableAnnualTurnover")
    public Boolean getEnableAnnualTurnover() {
        return enableAnnualTurnover;
    }

    @JsonProperty("enableAnnualTurnover")
    public void setEnableAnnualTurnover(Boolean enableAnnualTurnover) {
        this.enableAnnualTurnover = enableAnnualTurnover;
    }

    @JsonProperty("email")
    public String getEmail() {
        return email;
    }

    @JsonProperty("email")
    public void setEmail(String email) {
        this.email = email;
    }

    @JsonProperty("contactPerson")
    public String getContactPerson() {
        return contactPerson;
    }

    @JsonProperty("contactPerson")
    public void setContactPerson(String contactPerson) {
        this.contactPerson = contactPerson;
    }

    @JsonProperty("contactNo")
    public String getContactNo() {
        return contactNo;
    }

    @JsonProperty("contactNo")
    public void setContactNo(String contactNo) {
        this.contactNo = contactNo;
    }

    @JsonProperty("centralMerchantId")
    public Integer getCentralMerchantId() {
        return centralMerchantId;
    }

    @JsonProperty("centralMerchantId")
    public void setCentralMerchantId(Integer centralMerchantId) {
        this.centralMerchantId = centralMerchantId;
    }

    @JsonProperty("benName")
    public String getBenName() {
        return benName;
    }

    @JsonProperty("benName")
    public void setBenName(String benName) {
        this.benName = benName;
    }

    @JsonProperty("benIfsc")
    public String getBenIfsc() {
        return benIfsc;
    }

    @JsonProperty("benIfsc")
    public void setBenIfsc(String benIfsc) {
        this.benIfsc = benIfsc;
    }

    @JsonProperty("benConfiguration")
    public List<BenConfiguration> getBenConfiguration() {
        return benConfiguration;
    }

    @JsonProperty("benConfiguration")
    public void setBenConfiguration(List<BenConfiguration> benConfiguration) {
        this.benConfiguration = benConfiguration;
    }

    @JsonProperty("benBankName")
    public String getBenBankName() {
        return benBankName;
    }

    @JsonProperty("benBankName")
    public void setBenBankName(String benBankName) {
        this.benBankName = benBankName;
    }

    @JsonProperty("benBankBranch")
    public String getBenBankBranch() {
        return benBankBranch;
    }

    @JsonProperty("benBankBranch")
    public void setBenBankBranch(String benBankBranch) {
        this.benBankBranch = benBankBranch;
    }

    @JsonProperty("benAccNo")
    public String getBenAccNo() {
        return benAccNo;
    }

    @JsonProperty("benAccNo")
    public void setBenAccNo(String benAccNo) {
        this.benAccNo = benAccNo;
    }

    @JsonProperty("annualTurnover")
    public Integer getAnnualTurnover() {
        return annualTurnover;
    }

    @JsonProperty("annualTurnover")
    public void setAnnualTurnover(Integer annualTurnover) {
        this.annualTurnover = annualTurnover;
    }

}
