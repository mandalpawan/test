
package Aggregator.pojo.addEPOSPGDetailsList;

import java.io.Serializable;
import java.util.List;

import com.fasterxml.jackson.annotation.JsonProperty;


public class MdrDetail implements Serializable
{
    @JsonProperty("program")
    private Integer program=6;
    @JsonProperty("navCustId")
    private String navCustId="CUST232264";
    @JsonProperty("mdr")
    private List<Mdr> mdr;
    @JsonProperty("isMasterMid")
    private Boolean isMasterMid=false;
    @JsonProperty("hubPosId")
    private Integer hubPosId=56790;
    @JsonProperty("acquirer")
    private String acquirer="ICICI UPI";
    private final static long serialVersionUID = -9208486524979223190L;

    @JsonProperty("program")
    public Integer getProgram() {
        return program;
    }

    @JsonProperty("program")
    public void setProgram(Integer program) {
        this.program = program;
    }

    @JsonProperty("navCustId")
    public String getNavCustId() {
        return navCustId;
    }

    @JsonProperty("navCustId")
    public void setNavCustId(String navCustId) {
        this.navCustId = navCustId;
    }

    @JsonProperty("mdr")
    public List<Mdr> getMdr() {
        return mdr;
    }

    @JsonProperty("mdr")
    public void setMdr(List<Mdr> mdr) {
        this.mdr = mdr;
    }

    @JsonProperty("isMasterMid")
    public Boolean getIsMasterMid() {
        return isMasterMid;
    }

    @JsonProperty("isMasterMid")
    public void setIsMasterMid(Boolean isMasterMid) {
        this.isMasterMid = isMasterMid;
    }

    @JsonProperty("hubPosId")
    public Integer getHubPosId() {
        return hubPosId;
    }

    @JsonProperty("hubPosId")
    public void setHubPosId(Integer hubPosId) {
        this.hubPosId = hubPosId;
    }

    @JsonProperty("acquirer")
    public String getAcquirer() {
        return acquirer;
    }

    @JsonProperty("acquirer")
    public void setAcquirer(String acquirer) {
        this.acquirer = acquirer;
    }



}
