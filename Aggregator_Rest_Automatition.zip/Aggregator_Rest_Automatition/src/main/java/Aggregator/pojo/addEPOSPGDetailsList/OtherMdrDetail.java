
package Aggregator.pojo.addEPOSPGDetailsList;

import java.io.Serializable;
import java.util.List;

import com.fasterxml.jackson.annotation.JsonProperty;


public class OtherMdrDetail implements Serializable
{
    @JsonProperty("source")
    private Integer source=2;
    @JsonProperty("mdrDetails")
    private List<MdrDetail> mdrDetails;
    private final static long serialVersionUID = -6169090867193181714L;

    @JsonProperty("source")
    public Integer getSource() {
        return source;
    }

    @JsonProperty("source")
    public void setSource(Integer source) {
        this.source = source;
    }

    @JsonProperty("mdrDetails")
    public List<MdrDetail> getMdrDetails() {
        return mdrDetails;
    }

    @JsonProperty("mdrDetails")
    public void setMdrDetails(List<MdrDetail> mdrDetails) {
        this.mdrDetails = mdrDetails;
    }


}
