package Aggregator.pojo.addEPOSPGDetailsList;

public class PaymentDataGeneration {
    private BaseClass baseClass  = new BaseClass();
    private EpospgDetail epospgDetail = new EpospgDetail();
    private OtherMdrDetail otherMdrDetail = new OtherMdrDetail();
    private MdrDetail mdrDetail = new MdrDetail();
    private  Mdr mdr = new Mdr();
    private  TransactionType transactionType = new  TransactionType();
    private Slab slab = new Slab();
    private  BenConfiguration benConfiguration = new BenConfiguration();
    private AdditionalPrice additionalPrice = new AdditionalPrice();

    public  PaymentDataGeneration(){

    }

    public  BenConfiguration  setbenEntityId(Integer benEntityId){
        benConfiguration.setBenEntityId(benEntityId);
        return benConfiguration;
    }

    public  MdrDetail  sethubPosId(Integer hubPosId){
        mdrDetail.setHubPosId(hubPosId);
        return mdrDetail;
    }
}
