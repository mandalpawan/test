
package Aggregator.pojo.addEPOSPGDetailsList;


import java.io.Serializable;
import com.fasterxml.jackson.annotation.JsonProperty;

public class BenConfiguration implements Serializable
{

    @JsonProperty("benEntityLevel")
    private String benEntityLevel="POS";
    @JsonProperty("benEntityId")
    private Integer benEntityId=56790;
    private final static long serialVersionUID = -5063141736477827252L;

    @JsonProperty("benEntityLevel")
    public String getBenEntityLevel() {
        return benEntityLevel;
    }

    @JsonProperty("benEntityLevel")
    public void setBenEntityLevel(String benEntityLevel) {
        this.benEntityLevel = benEntityLevel;
    }

    @JsonProperty("benEntityId")
    public Integer getBenEntityId() {
        return benEntityId;
    }

    @JsonProperty("benEntityId")
    public void setBenEntityId(Integer benEntityId) {
        this.benEntityId = benEntityId;
    }

}
