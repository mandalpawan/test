package Aggregator.pojo.transaction;


import java.time.LocalDateTime;

public class KafkaMessage {
    private String subTransactions_0_bankTid;
    private String subTransactions_0_card_bankRrn;
    private String subTransactions_0_card_cardNum;
    private String subTransactions_0_acquirer_name;
    private int subTransactions_0_acquirer_id;
    private LocalDateTime transactionDate;
    private double subTransactions_0_convertedAmount_currencyConversion_forexConversionBaseRate;
    private double subTransactions_0_convertedAmount_currencyConversion_forexConversionRate;
    private double subTransactions_0_convertedAmount_currencyConversion_forexConversionMarkUpRate;
    private int rocId;
    private String merchant_sellerId;
    private String merchant_mvv;
    private String subTransactions_0_card_binInfo_scheme;
    private String subTransactions_0_issuer_name;
    private String subTransactions_0_card_binInfo_cardCategory;
    private String merchant_merchantId;
    private String subTransactions_0_bankMid;
    private String parentTransactionAmount_currencyCode;
    private String parentTransactionId;
    private int authAmount_currencyCode;
    private String merchantUniqueId;
    private String authAmount_amount;
    private String invoiceAmount_amount;
    private double subTransactions_0_convertedAmount_amount;
    private String subTransactions_0_program_name;
    private int subTransactions_0_amount_currencyCode;
    private String parentTransactionAmount_amount;
    private String transactioneventid;
    private String batchKey;
    private int batchId;
    private String merchant_storeId;
    private String merchant_posId;
    private String subTransactions_0_card_binInfo_binId;
    private long additionalInfo_lsnValue;
    private Boolean subTransactions_0_card_binInfo_isOffUs;
    private String additionalInfo_additionalProp1;
    private String additionalInfo_additionalProp2;
    private String additionalInfo_additionalProp3;
    private String subTransactions_0_additionalInfo_additionalProp2;
    private String subTransactions_0_additionalInfo_additionalProp1;
    private String subTransactions_0_additionalInfo_additionalProp3;
    private String merchant_mcc;
    private String customerRefNo;
    private String subTransactions_0_originalAmount_amount;
    private String subTransactions_0_originalAmount_currencyCode;
    private String additionalInfo_reversalTxnId;
    private String subTransactions_0_amount_amount;
    private String notOnSellRate;
    private int subTransactions_0_convertedAmount_currencyConversion_currencyCode;
    private int invoiceAmount_currencyCode;
    private String bankRefNo;
    private String subTransactions_0_hostTransactionId;
    private boolean subTransactions_0_card_binInfo_isForeignCard;
    private String subTransactions_0_card_binInfo_cardType;
    private String subTransactions_0_upi_merchantVpa;
    private String subTransactions_0_upi_payerVpa;
    private String subTransactions_0_upi_qrType;
    private String subTransactions_0_upi_transactionType;
    private String transactionType;
    private String transactionStatus;
    private String orderId;
    private String subTransactions_0_card_bankApprovalCode;
    private int invoiceId;
    private String transactionId;

    // Getters and Setters
    public String getSubTransactions_0_bankTid() {
        return subTransactions_0_bankTid;
    }

    public void setSubTransactions_0_bankTid(String subTransactions_0_bankTid) {
        this.subTransactions_0_bankTid = subTransactions_0_bankTid;
    }

    public String getSubTransactions_0_card_bankRrn() {
        return subTransactions_0_card_bankRrn;
    }

    public void setSubTransactions_0_card_bankRrn(String subTransactions_0_card_bankRrn) {
        this.subTransactions_0_card_bankRrn = subTransactions_0_card_bankRrn;
    }

    public String getSubTransactions_0_card_cardNum() {
        return subTransactions_0_card_cardNum;
    }

    public void setSubTransactions_0_card_cardNum(String subTransactions_0_card_cardNum) {
        this.subTransactions_0_card_cardNum = subTransactions_0_card_cardNum;
    }

    public String getSubTransactions_0_acquirer_name() {
        return subTransactions_0_acquirer_name;
    }

    public void setSubTransactions_0_acquirer_name(String subTransactions_0_acquirer_name) {
        this.subTransactions_0_acquirer_name = subTransactions_0_acquirer_name;
    }

    public int getSubTransactions_0_acquirer_id() {
        return subTransactions_0_acquirer_id;
    }

    public void setSubTransactions_0_acquirer_id(int subTransactions_0_acquirer_id) {
        this.subTransactions_0_acquirer_id = subTransactions_0_acquirer_id;
    }

    public LocalDateTime getTransactionDate() {
        return transactionDate;
    }

    public void setTransactionDate(LocalDateTime transactionDate) {
        this.transactionDate = transactionDate;
    }

    public double getSubTransactions_0_convertedAmount_currencyConversion_forexConversionBaseRate() {
        return subTransactions_0_convertedAmount_currencyConversion_forexConversionBaseRate;
    }

    public void setSubTransactions_0_convertedAmount_currencyConversion_forexConversionBaseRate(double subTransactions_0_convertedAmount_currencyConversion_forexConversionBaseRate) {
        this.subTransactions_0_convertedAmount_currencyConversion_forexConversionBaseRate = subTransactions_0_convertedAmount_currencyConversion_forexConversionBaseRate;
    }

    public double getSubTransactions_0_convertedAmount_currencyConversion_forexConversionRate() {
        return subTransactions_0_convertedAmount_currencyConversion_forexConversionRate;
    }

    public void setSubTransactions_0_convertedAmount_currencyConversion_forexConversionRate(double subTransactions_0_convertedAmount_currencyConversion_forexConversionRate) {
        this.subTransactions_0_convertedAmount_currencyConversion_forexConversionRate = subTransactions_0_convertedAmount_currencyConversion_forexConversionRate;
    }

    public double getSubTransactions_0_convertedAmount_currencyConversion_forexConversionMarkUpRate() {
        return subTransactions_0_convertedAmount_currencyConversion_forexConversionMarkUpRate;
    }

    public void setSubTransactions_0_convertedAmount_currencyConversion_forexConversionMarkUpRate(double subTransactions_0_convertedAmount_currencyConversion_forexConversionMarkUpRate) {
        this.subTransactions_0_convertedAmount_currencyConversion_forexConversionMarkUpRate = subTransactions_0_convertedAmount_currencyConversion_forexConversionMarkUpRate;
    }

    public int getRocId() {
        return rocId;
    }

    public void setRocId(int rocId) {
        this.rocId = rocId;
    }

    public String getMerchant_sellerId() {
        return merchant_sellerId;
    }

    public void setMerchant_sellerId(String merchant_sellerId) {
        this.merchant_sellerId = merchant_sellerId;
    }

    public String getMerchant_mvv() {
        return merchant_mvv;
    }

    public void setMerchant_mvv(String merchant_mvv) {
        this.merchant_mvv = merchant_mvv;
    }

    public String getSubTransactions_0_card_binInfo_scheme() {
        return subTransactions_0_card_binInfo_scheme;
    }

    public void setSubTransactions_0_card_binInfo_scheme(String subTransactions_0_card_binInfo_scheme) {
        this.subTransactions_0_card_binInfo_scheme = subTransactions_0_card_binInfo_scheme;
    }

    public String getSubTransactions_0_issuer_name() {
        return subTransactions_0_issuer_name;
    }

    public void setSubTransactions_0_issuer_name(String subTransactions_0_issuer_name) {
        this.subTransactions_0_issuer_name = subTransactions_0_issuer_name;
    }

    public String getSubTransactions_0_card_binInfo_cardCategory() {
        return subTransactions_0_card_binInfo_cardCategory;
    }

    public void setSubTransactions_0_card_binInfo_cardCategory(String subTransactions_0_card_binInfo_cardCategory) {
        this.subTransactions_0_card_binInfo_cardCategory = subTransactions_0_card_binInfo_cardCategory;
    }

    public String getMerchant_merchantId() {
        return merchant_merchantId;
    }

    public void setMerchant_merchantId(String merchant_merchantId) {
        this.merchant_merchantId = merchant_merchantId;
    }

    public String getSubTransactions_0_bankMid() {
        return subTransactions_0_bankMid;
    }

    public void setSubTransactions_0_bankMid(String subTransactions_0_bankMid) {
        this.subTransactions_0_bankMid = subTransactions_0_bankMid;
    }

    public String getParentTransactionAmount_currencyCode() {
        return parentTransactionAmount_currencyCode;
    }

    public void setParentTransactionAmount_currencyCode(String parentTransactionAmount_currencyCode) {
        this.parentTransactionAmount_currencyCode = parentTransactionAmount_currencyCode;
    }

    public String getParentTransactionId() {
        return parentTransactionId;
    }

    public void setParentTransactionId(String parentTransactionId) {
        this.parentTransactionId = parentTransactionId;
    }

    public int getAuthAmount_currencyCode() {
        return authAmount_currencyCode;
    }

    public void setAuthAmount_currencyCode(int authAmount_currencyCode) {
        this.authAmount_currencyCode = authAmount_currencyCode;
    }

    public String getMerchantUniqueId() {
        return merchantUniqueId;
    }

    public void setMerchantUniqueId(String merchantUniqueId) {
        this.merchantUniqueId = merchantUniqueId;
    }

    public String getAuthAmount_amount() {
        return authAmount_amount;
    }

    public void setAuthAmount_amount(String authAmount_amount) {
        this.authAmount_amount = authAmount_amount;
    }

    public String getInvoiceAmount_amount() {
        return invoiceAmount_amount;
    }

    public void setInvoiceAmount_amount(String invoiceAmount_amount) {
        this.invoiceAmount_amount = invoiceAmount_amount;
    }

    public double getSubTransactions_0_convertedAmount_amount() {
        return subTransactions_0_convertedAmount_amount;
    }

    public void setSubTransactions_0_convertedAmount_amount(double subTransactions_0_convertedAmount_amount) {
        this.subTransactions_0_convertedAmount_amount = subTransactions_0_convertedAmount_amount;
    }

    public String getSubTransactions_0_program_name() {
        return subTransactions_0_program_name;
    }

    public void setSubTransactions_0_program_name(String subTransactions_0_program_name) {
        this.subTransactions_0_program_name = subTransactions_0_program_name;
    }

    public int getSubTransactions_0_amount_currencyCode() {
        return subTransactions_0_amount_currencyCode;
    }

    public void setSubTransactions_0_amount_currencyCode(int subTransactions_0_amount_currencyCode) {
        this.subTransactions_0_amount_currencyCode = subTransactions_0_amount_currencyCode;
    }

    public String getParentTransactionAmount_amount() {
        return parentTransactionAmount_amount;
    }

    public void setParentTransactionAmount_amount(String parentTransactionAmount_amount) {
        this.parentTransactionAmount_amount = parentTransactionAmount_amount;
    }

    public String getTransactioneventid() {
        return transactioneventid;
    }

    public void setTransactioneventid(String transactioneventid) {
        this.transactioneventid = transactioneventid;
    }

    public String getBatchKey() {
        return batchKey;
    }

    public void setBatchKey(String batchKey) {
        this.batchKey = batchKey;
    }

    public int getBatchId() {
        return batchId;
    }

    public void setBatchId(int batchId) {
        this.batchId = batchId;
    }

    public String getMerchant_storeId() {
        return merchant_storeId;
    }

    public void setMerchant_storeId(String merchant_storeId) {
        this.merchant_storeId = merchant_storeId;
    }

    public String getMerchant_posId() {
        return merchant_posId;
    }

    public void setMerchant_posId(String merchant_posId) {
        this.merchant_posId = merchant_posId;
    }

    public String getSubTransactions_0_card_binInfo_binId() {
        return subTransactions_0_card_binInfo_binId;
    }

    public void setSubTransactions_0_card_binInfo_binId(String subTransactions_0_card_binInfo_binId) {
        this.subTransactions_0_card_binInfo_binId = subTransactions_0_card_binInfo_binId;
    }

    public long getAdditionalInfo_lsnValue() {
        return additionalInfo_lsnValue;
    }

    public void setAdditionalInfo_lsnValue(long additionalInfo_lsnValue) {
        this.additionalInfo_lsnValue = additionalInfo_lsnValue;
    }

    public Boolean getSubTransactions_0_card_binInfo_isOffUs() {
        return subTransactions_0_card_binInfo_isOffUs;
    }

    public void setSubTransactions_0_card_binInfo_isOffUs(Boolean subTransactions_0_card_binInfo_isOffUs) {
        this.subTransactions_0_card_binInfo_isOffUs = subTransactions_0_card_binInfo_isOffUs;
    }

    public String getAdditionalInfo_additionalProp1() {
        return additionalInfo_additionalProp1;
    }

    public void setAdditionalInfo_additionalProp1(String additionalInfo_additionalProp1) {
        this.additionalInfo_additionalProp1 = additionalInfo_additionalProp1;
    }

    public String getAdditionalInfo_additionalProp2() {
        return additionalInfo_additionalProp2;
    }

    public void setAdditionalInfo_additionalProp2(String additionalInfo_additionalProp2) {
        this.additionalInfo_additionalProp2 = additionalInfo_additionalProp2;
    }

    public String getAdditionalInfo_additionalProp3() {
        return additionalInfo_additionalProp3;
    }

    public void setAdditionalInfo_additionalProp3(String additionalInfo_additionalProp3) {
        this.additionalInfo_additionalProp3 = additionalInfo_additionalProp3;
    }

    public String getSubTransactions_0_additionalInfo_additionalProp2() {
        return subTransactions_0_additionalInfo_additionalProp2;
    }

    public void setSubTransactions_0_additionalInfo_additionalProp2(String subTransactions_0_additionalInfo_additionalProp2) {
        this.subTransactions_0_additionalInfo_additionalProp2 = subTransactions_0_additionalInfo_additionalProp2;
    }

    public String getSubTransactions_0_additionalInfo_additionalProp1() {
        return subTransactions_0_additionalInfo_additionalProp1;
    }

    public void setSubTransactions_0_additionalInfo_additionalProp1(String subTransactions_0_additionalInfo_additionalProp1) {
        this.subTransactions_0_additionalInfo_additionalProp1 = subTransactions_0_additionalInfo_additionalProp1;
    }

    public String getSubTransactions_0_additionalInfo_additionalProp3() {
        return subTransactions_0_additionalInfo_additionalProp3;
    }

    public void setSubTransactions_0_additionalInfo_additionalProp3(String subTransactions_0_additionalInfo_additionalProp3) {
        this.subTransactions_0_additionalInfo_additionalProp3 = subTransactions_0_additionalInfo_additionalProp3;
    }

    public String getMerchant_mcc() {
        return merchant_mcc;
    }

    public void setMerchant_mcc(String merchant_mcc) {
        this.merchant_mcc = merchant_mcc;
    }

    public String getCustomerRefNo() {
        return customerRefNo;
    }

    public void setCustomerRefNo(String customerRefNo) {
        this.customerRefNo = customerRefNo;
    }

    public String getSubTransactions_0_originalAmount_amount() {
        return subTransactions_0_originalAmount_amount;
    }

    public void setSubTransactions_0_originalAmount_amount(String subTransactions_0_originalAmount_amount) {
        this.subTransactions_0_originalAmount_amount = subTransactions_0_originalAmount_amount;
    }

    public String getSubTransactions_0_originalAmount_currencyCode() {
        return subTransactions_0_originalAmount_currencyCode;
    }

    public void setSubTransactions_0_originalAmount_currencyCode(String subTransactions_0_originalAmount_currencyCode) {
        this.subTransactions_0_originalAmount_currencyCode = subTransactions_0_originalAmount_currencyCode;
    }

    public String getAdditionalInfo_reversalTxnId() {
        return additionalInfo_reversalTxnId;
    }

    public void setAdditionalInfo_reversalTxnId(String additionalInfo_reversalTxnId) {
        this.additionalInfo_reversalTxnId = additionalInfo_reversalTxnId;
    }

    public String getSubTransactions_0_amount_amount() {
        return subTransactions_0_amount_amount;
    }

    public void setSubTransactions_0_amount_amount(String subTransactions_0_amount_amount) {
        this.subTransactions_0_amount_amount = subTransactions_0_amount_amount;
    }

    public String getNotOnSellRate() {
        return notOnSellRate;
    }

    public void setNotOnSellRate(String notOnSellRate) {
        this.notOnSellRate = notOnSellRate;
    }

    public int getSubTransactions_0_convertedAmount_currencyConversion_currencyCode() {
        return subTransactions_0_convertedAmount_currencyConversion_currencyCode;
    }

    public void setSubTransactions_0_convertedAmount_currencyConversion_currencyCode(int subTransactions_0_convertedAmount_currencyConversion_currencyCode) {
        this.subTransactions_0_convertedAmount_currencyConversion_currencyCode = subTransactions_0_convertedAmount_currencyConversion_currencyCode;
    }

    public int getInvoiceAmount_currencyCode() {
        return invoiceAmount_currencyCode;
    }

    public void setInvoiceAmount_currencyCode(int invoiceAmount_currencyCode) {
        this.invoiceAmount_currencyCode = invoiceAmount_currencyCode;
    }

    public String getBankRefNo() {
        return bankRefNo;
    }

    public void setBankRefNo(String bankRefNo) {
        this.bankRefNo = bankRefNo;
    }

    public String getSubTransactions_0_hostTransactionId() {
        return subTransactions_0_hostTransactionId;
    }

    public void setSubTransactions_0_hostTransactionId(String subTransactions_0_hostTransactionId) {
        this.subTransactions_0_hostTransactionId = subTransactions_0_hostTransactionId;
    }

    public boolean isSubTransactions_0_card_binInfo_isForeignCard() {
        return subTransactions_0_card_binInfo_isForeignCard;
    }

    public void setSubTransactions_0_card_binInfo_isForeignCard(boolean subTransactions_0_card_binInfo_isForeignCard) {
        this.subTransactions_0_card_binInfo_isForeignCard = subTransactions_0_card_binInfo_isForeignCard;
    }

    public String getSubTransactions_0_card_binInfo_cardType() {
        return subTransactions_0_card_binInfo_cardType;
    }

    public void setSubTransactions_0_card_binInfo_cardType(String subTransactions_0_card_binInfo_cardType) {
        this.subTransactions_0_card_binInfo_cardType = subTransactions_0_card_binInfo_cardType;
    }

    public String getSubTransactions_0_upi_merchantVpa() {
        return subTransactions_0_upi_merchantVpa;
    }

    public void setSubTransactions_0_upi_merchantVpa(String subTransactions_0_upi_merchantVpa) {
        this.subTransactions_0_upi_merchantVpa = subTransactions_0_upi_merchantVpa;
    }

    public String getSubTransactions_0_upi_payerVpa() {
        return subTransactions_0_upi_payerVpa;
    }

    public void setSubTransactions_0_upi_payerVpa(String subTransactions_0_upi_payerVpa) {
        this.subTransactions_0_upi_payerVpa = subTransactions_0_upi_payerVpa;
    }

    public String getSubTransactions_0_upi_qrType() {
        return subTransactions_0_upi_qrType;
    }

    public void setSubTransactions_0_upi_qrType(String subTransactions_0_upi_qrType) {
        this.subTransactions_0_upi_qrType = subTransactions_0_upi_qrType;
    }

    public String getSubTransactions_0_upi_transactionType() {
        return subTransactions_0_upi_transactionType;
    }

    public void setSubTransactions_0_upi_transactionType(String subTransactions_0_upi_transactionType) {
        this.subTransactions_0_upi_transactionType = subTransactions_0_upi_transactionType;
    }

    public String getTransactionType() {
        return transactionType;
    }

    public void setTransactionType(String transactionType) {
        this.transactionType = transactionType;
    }

    public String getTransactionStatus() {
        return transactionStatus;
    }

    public void setTransactionStatus(String transactionStatus) {
        this.transactionStatus = transactionStatus;
    }

    public String getOrderId() {
        return orderId;
    }

    public void setOrderId(String orderId) {
        this.orderId = orderId;
    }

    public String getSubTransactions_0_card_bankApprovalCode() {
        return subTransactions_0_card_bankApprovalCode;
    }

    public void setSubTransactions_0_card_bankApprovalCode(String subTransactions_0_card_bankApprovalCode) {
        this.subTransactions_0_card_bankApprovalCode = subTransactions_0_card_bankApprovalCode;
    }

    public int getInvoiceId() {
        return invoiceId;
    }

    public void setInvoiceId(int invoiceId) {
        this.invoiceId = invoiceId;
    }

    public String getTransactionId() {
        return transactionId;
    }

    public void setTransactionId(String transactionId) {
        this.transactionId = transactionId;
    }

    // Data generation function
    public static KafkaMessage generateSampleData() {
        KafkaMessage transaction = new KafkaMessage();
        transaction.setSubTransactions_0_bankTid("ICICIUPI09");
        transaction.setSubTransactions_0_card_bankRrn("");
        transaction.setSubTransactions_0_card_cardNum("***********1234");
        transaction.setSubTransactions_0_acquirer_name("ICICI UPI");
        transaction.setSubTransactions_0_acquirer_id(1998891);
        transaction.setTransactionDate(LocalDateTime.parse("2024-06-05T14:40:58.722"));
        transaction.setSubTransactions_0_convertedAmount_currencyConversion_forexConversionBaseRate(0);
        transaction.setSubTransactions_0_convertedAmount_currencyConversion_forexConversionRate(0);
        transaction.setSubTransactions_0_convertedAmount_currencyConversion_forexConversionMarkUpRate(0);
        transaction.setRocId(106);
        transaction.setMerchant_sellerId("11011234");
        transaction.setMerchant_mvv("425104");
        transaction.setSubTransactions_0_card_binInfo_scheme(null);
        transaction.setSubTransactions_0_issuer_name("");
        transaction.setSubTransactions_0_card_binInfo_cardCategory(null);
        transaction.setMerchant_merchantId("776480");
        transaction.setSubTransactions_0_bankMid("ICICIUPI09");
        transaction.setParentTransactionAmount_currencyCode(null);
        transaction.setParentTransactionId(null);
        transaction.setAuthAmount_currencyCode(356);
        transaction.setMerchantUniqueId("pc:363310");
        transaction.setAuthAmount_amount("2000");
        transaction.setInvoiceAmount_amount("2000");
        transaction.setSubTransactions_0_convertedAmount_amount(205);
        transaction.setSubTransactions_0_program_name("UPI");
        transaction.setSubTransactions_0_amount_currencyCode(356);
        transaction.setParentTransactionAmount_amount(null);
        transaction.setTransactioneventid("pc:card:1893777036");
        transaction.setBatchKey("pc:card:934226");
        transaction.setBatchId(934226);
        transaction.setMerchant_storeId("776490");
        transaction.setMerchant_posId("776501");
        transaction.setSubTransactions_0_card_binInfo_binId("401200");
        transaction.setAdditionalInfo_lsnValue(1708328621130L);
        transaction.setSubTransactions_0_card_binInfo_isOffUs(null);
        transaction.setAdditionalInfo_additionalProp1("pc");
        transaction.setAdditionalInfo_additionalProp2("card");
        transaction.setAdditionalInfo_additionalProp3(null);
        transaction.setSubTransactions_0_additionalInfo_additionalProp2(null);
        transaction.setSubTransactions_0_additionalInfo_additionalProp1(null);
        transaction.setSubTransactions_0_additionalInfo_additionalProp3(null);
        transaction.setMerchant_mcc(null);
        transaction.setCustomerRefNo(null);
        transaction.setSubTransactions_0_originalAmount_amount(null);
        transaction.setSubTransactions_0_originalAmount_currencyCode(null);
        transaction.setAdditionalInfo_reversalTxnId(null);
        transaction.setSubTransactions_0_amount_amount("2000");
        transaction.setNotOnSellRate("false");
        transaction.setSubTransactions_0_convertedAmount_currencyConversion_currencyCode(1);
        transaction.setInvoiceAmount_currencyCode(356);
        transaction.setBankRefNo("");
        transaction.setSubTransactions_0_hostTransactionId("146194188");
        transaction.setSubTransactions_0_card_binInfo_isForeignCard(true);
        transaction.setSubTransactions_0_card_binInfo_cardType(null);
        transaction.setSubTransactions_0_upi_merchantVpa("pinelabs.2427962@icici");
        transaction.setSubTransactions_0_upi_payerVpa("8056221750@axl");
        transaction.setSubTransactions_0_upi_qrType("DYNAMICQR");
        transaction.setSubTransactions_0_upi_transactionType("SALE");
        transaction.setTransactionType("SALE");
        transaction.setTransactionStatus("SUCCESS");
        transaction.setOrderId("000046231266129");
        transaction.setSubTransactions_0_card_bankApprovalCode("239948");
        transaction.setInvoiceId(789);
        transaction.setTransactionId("2024060510");

        return transaction;
    }
}
