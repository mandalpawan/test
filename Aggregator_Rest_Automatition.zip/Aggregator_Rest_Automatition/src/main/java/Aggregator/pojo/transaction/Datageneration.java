//package Aggregator.pojo.transaction;
//
//import java.time.LocalDateTime;
//
//public class Datageneration {
//    KafkaMessage transaction = new KafkaMessage();
//

//}
