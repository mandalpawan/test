package Aggregator.utiles;

import io.restassured.response.Response;

public class ScenarioContext {
    public Response previousResponse;


    public ScenarioContext() {
    }

    public Response getPreviousResponse(){
        return this.previousResponse;
    }

    public Response setPreviousResponse(Response response){
        return this.previousResponse = response;
    }
}
