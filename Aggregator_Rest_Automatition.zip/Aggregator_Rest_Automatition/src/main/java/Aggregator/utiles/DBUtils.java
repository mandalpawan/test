package Aggregator.utiles;

import org.junit.Test;

import java.sql.*;
import java.util.HashMap;
import java.util.Map;

import static org.hamcrest.MatcherAssert.assertThat;
import static org.testng.Assert.assertEquals;

public class DBUtils {

    public void checkStatus(String tableName,int processed,long externalReferenceId){
        try {
            String query = "select * from "+tableName +" (nolock) where lms_reference_id = "+externalReferenceId;
            Map<String, String> result = DBConnectionManager.getQueryResultAsStringMap(query);
            int proccess = Integer.parseInt(result.get("processed"));
            assertEquals(processed, proccess, "Expected processed status code "+processed);

//            for (Map.Entry<String, String> entry : result.entrySet()) {
//                System.out.println(entry.getKey() + ":" + entry.getValue());
//            }

        }catch (Exception e){
            System.out.println("Exception" + e);
        }
    }

    @Test
    public void data(){
        try {
            Connection conn = DBConnectionManager.getConnection();

            Statement statement = conn.createStatement();

            String query = "select * from lms_staging_data_for_pg_and_epos(nolock) where lms_reference_id = 190100091344";


            Map<String, String> result = DBConnectionManager.getQueryResultAsStringMap(query);


            for (Map.Entry<String, String> entry : result.entrySet()) {
                System.out.println(entry.getKey() + ":" + entry.getValue());
            }

        }catch (Exception e){
            System.out.println("Exception" + e);
        }


    }
}


