package Aggregator.utiles;

import io.restassured.RestAssured;
import io.restassured.filter.log.LogDetail;
import io.restassured.filter.log.RequestLoggingFilter;
import io.restassured.filter.log.ResponseLoggingFilter;
import io.restassured.response.Response;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

import java.io.PrintStream;

import static Aggregator.api.SpecBuilder.getRequestSpec;
import static Aggregator.api.SpecBuilder.getResponseSpec;
import static io.restassured.RestAssured.given;
import org.testng.annotations.BeforeClass;

public class Aggregator_Request {
    private static final Logger logger = LogManager.getLogger(Aggregator_Request.class);

    @BeforeClass
    public void setup() {
        PrintStream logStream = new PrintStream(System.out);

        RestAssured.filters(
                new RequestLoggingFilter(LogDetail.ALL, logStream),
                new ResponseLoggingFilter(LogDetail.ALL, logStream)
        );
    }

    static public Response getAPI(String URL,String endpoint){
        return given(getRequestSpec(URL))
                .when().get(endpoint)
                .then().spec(getResponseSpec())
                .extract().
                response();
    }

    static public Response postAPI(String URL,String endpoint, Object data){
        logger.info("Starting testGetEndpoint test");
        return  given(getRequestSpec(URL))
                .body(data)
                .when()
                .post(endpoint)
                .then().spec(getResponseSpec())
                .assertThat()
                .extract().
                response();
    }
}

