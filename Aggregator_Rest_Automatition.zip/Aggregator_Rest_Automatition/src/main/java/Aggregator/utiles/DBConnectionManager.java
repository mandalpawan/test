package Aggregator.utiles;

import org.apache.commons.dbcp2.BasicDataSource;

import java.sql.*;
import java.util.HashMap;
import java.util.Map;


public class DBConnectionManager {
    private static BasicDataSource dataSource;
    static  String dbConnectionURL = "jdbc:sqlserver://AGGREGATORTEST.pinelabs.com:51970;databaseName=aggregatordb";
    static  String userName = "SVC_Sattlement_Test";
    static  String pwd = "skS#%%O9dLbf^t5E1fO2Mg!W";

    static {
        dataSource = new BasicDataSource();
        dataSource.setUrl(dbConnectionURL);
        dataSource.setUsername(userName);
        dataSource.setPassword(pwd);
        dataSource.setDriverClassName("com.microsoft.sqlserver.jdbc.SQLServerDriver");
        dataSource.setMinIdle(5);
        dataSource.setMaxIdle(10);
        dataSource.setMaxOpenPreparedStatements(100);
    }

    public static Connection getConnection() throws SQLException {
        return dataSource.getConnection();
    }

    public static int executeUpdateQuery(String query) throws SQLException {
        Connection conUpdateQuery = getConnection();
        Statement stmt = getStatement(conUpdateQuery);

        int totalRowsUpdated = stmt.executeUpdate(query);
        if (stmt != null) {
            stmt.close();
        }

        if (conUpdateQuery != null) {
            conUpdateQuery.close();
        }

        return totalRowsUpdated;
    }

    public static Map<String, String> getQueryResultAsStringMap(String query) throws SQLException {
        Connection con1 = getConnection();
        Statement stmt = getStatement(con1);
        ResultSet result = stmt.executeQuery(query);
        Map<String, String> resultsMap = resultSetToStringMap(result);
        if (stmt != null) {
            stmt.close();
        }

        if (con1 != null) {
            con1.close();
        }

        return resultsMap;
    }

    public static Statement getStatement(Connection connection) throws SQLException {
        return connection.createStatement(1004, 1007);
    }

    public static Map<String, String> resultSetToStringMap(ResultSet resultSet) throws SQLException {
        ResultSetMetaData resultSetMetaData = resultSet.getMetaData();
        HashMap retMap = new HashMap();

        while(resultSet.next()) {
            for(int i = 1; i <= resultSetMetaData.getColumnCount(); ++i) {
                Object rsObj;
                if (!resultSetMetaData.getColumnTypeName(i).equals("bit")) {
                    rsObj = resultSet.getObject(i);
                } else {
                    rsObj = resultSet.getByte(i);
                }

                if (rsObj != null) {
                    retMap.put(resultSetMetaData.getColumnName(i), rsObj.toString());
                } else {
                    retMap.put(resultSetMetaData.getColumnName(i), (String)rsObj);
                }
            }
        }

        return retMap;
    }
}
